#include <iostream>
#include <string>
#include <cstdlib>
using namespace std;
#include "Vendedor.h"
#include "Gerente.h"

int main() {
  string nome, departamento;
  double salario, percentualcomissao, novoSalario;
  int opcao;
  
  std::cout << "Escolha uma opção:" << endl;
  cout<<"1-Vendedor\n2-Gerente\n";
  cin>>opcao;

    if(opcao == 1){
      cout << "----Digite os seus dados de Vendedor----"<< endl;
      cout << "Percentual de Comissao: ";
      cin >> percentualcomissao;
      cout << "Nome: ";
      cin.ignore();
      getline( cin, nome );
      cout << "Salário: ";
      cin>>salario;
      Vendedor Vendedor1 = Vendedor(percentualcomissao,nome, salario);
      novoSalario = Vendedor1.calcularSalario(salario, percentualcomissao);
      Vendedor1.toString();
      cout <<"Salário Com Comissão: " << novoSalario;
      }
      
    else if(opcao ==2){
          cout << "----Digite os seus dados de Gerente----"<< endl;
       cout << "Nome: ";
       cin.ignore();
       getline( cin, nome );;
       cout << "Salário: ";
       cin>>salario;
       cout << "Departamento: ";
       cin>> departamento;
       Gerente Gerente1 = Gerente(nome, salario, departamento);   
       Gerente1.toString();
      }
      
    else{
       cout << "Opção Inválida";
      }
  
  return 0;
}