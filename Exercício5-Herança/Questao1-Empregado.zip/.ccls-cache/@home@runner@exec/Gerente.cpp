#include <string>
#include <iostream>
#include "Gerente.h"

using namespace std;

Gerente::Gerente(string novonome, double novosalario, string novodepartamento): Empregado(novonome, novosalario){
  this-> departamento = novodepartamento;
}

void Gerente::setDEPARTAMENTO(string novodepartamento){
  this->departamento = novodepartamento;
}

string Gerente::getDEPARTAMENTO(){
  return this-> departamento;
}

void Gerente::toString(){
  cout << "\n--------Informações do Gerente--------"<< endl;
  cout << "Nome : " << getNOME() << endl;
  cout << "Salario: " << getSALARIO() << endl;
  cout << "Departamento: " << getDEPARTAMENTO() << endl;
}