#ifndef Gerente_H
#define Gerente_H

#include "Empregado.h"
#include <iostream>
#include <string>

using namespace std;

class Gerente: public Empregado{

  public:
    string departamento;
    Gerente(string novonome, double novosalario, string novodepartamento);
    void setDEPARTAMENTO(string novodepartamento);
    string getDEPARTAMENTO();
    void toString();
  

};
#endif