#ifndef Empregado_H
#define Empregado_H

#include <iostream>
#include <string>

using namespace std;

class Empregado{

  protected:
    double salario;

  public:
    string nome;

   Empregado(string novonome, double novosalario){
    this -> nome = novonome;
    this -> salario = novosalario;
  }

  void setNOME(string novonome);
  string getNOME();
  void setSALARIO(double novosalario);
  double getSALARIO();

}; 
#endif