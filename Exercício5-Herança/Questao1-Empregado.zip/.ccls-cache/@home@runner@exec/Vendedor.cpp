#include <string>
#include "Vendedor.h"
using namespace std;

Vendedor::Vendedor(double novopercentualComissao, string novonome, double novosalario) : Empregado(novonome, novosalario){
  this -> percentualComissao = novopercentualComissao;
}

void Vendedor::setPERCENTUALCOMISSAO(double novopercentualComissao){
  this -> percentualComissao = novopercentualComissao;
}

double Vendedor::getPERCENTUALCOMISSAO(){
  return this -> percentualComissao;
}

double Vendedor:: calcularSalario(double salario, double percentualComissao){
  double novoSalario;
  novoSalario = salario + (salario*(percentualComissao/100));
  return novoSalario;
}

void Vendedor:: toString(){
  cout << "\n--------Informações do Vendedor--------"<< endl;
  cout << "Nome : " << getNOME() << endl;
  cout << "Salario sem comissão: " << getSALARIO() << endl;
}