#include <iostream>
#include <string>
#include "Empregado.h"

using namespace std;

void Empregado::setNOME(string novonome){
  this->nome = novonome;
}

void Empregado::setSALARIO(double novosalario){
  this->salario = novosalario;
}

string Empregado::getNOME(){
  return this -> nome;
}

double Empregado::getSALARIO(){
  return this->salario;
}