#ifndef Vendedor_H
#define Vendedor_H

#include <string>
#include "Empregado.h"

using namespace std;

class Vendedor : public Empregado{
 public:
    double percentualComissao;
    double calcularSalario(double salario, double percentualComissao);
    //  Construtor
    Vendedor(double novopercentualComissao, string novonome, double novosalario);
    void setPERCENTUALCOMISSAO(double novopercentualComissao);
    double getPERCENTUALCOMISSAO();
    void toString();

};
#endif