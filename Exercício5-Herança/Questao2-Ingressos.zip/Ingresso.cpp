#include "Ingresso.h"
#include <iostream>
#include <string>

using namespace std;

void Ingresso::setVALOR(double novovalor){
  this -> valor = novovalor;
}

double Ingresso::getVALOR(){
  return this -> valor;
}

void Ingresso::toString(){
  cout << "\n----Informações sobre o seu ingresso----"<< endl;
  cout << "Valor do Ingresso: " << getVALOR();
}