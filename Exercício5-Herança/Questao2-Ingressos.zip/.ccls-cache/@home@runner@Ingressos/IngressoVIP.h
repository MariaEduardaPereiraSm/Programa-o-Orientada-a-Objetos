#ifndef IngressoVIP_H
#define IngressoVIP_H
#include "Ingresso.h"

class IngressoVIP : public Ingresso{

  public:
    double valorAdicional;

  //Construtor
  IngressoVIP(double novoValorAdicional, double valor);

  //Metodos
  void setVALORADICIONAL(double novoValorAdicional);
  double getVALORADICIONAL();
  void toString();

};
#endif
