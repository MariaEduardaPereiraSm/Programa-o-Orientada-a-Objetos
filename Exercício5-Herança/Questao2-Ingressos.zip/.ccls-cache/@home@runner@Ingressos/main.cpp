#include <iostream>
#include <string>
#include "Ingresso.h"
#include "IngressoVIP.h"
using namespace std;

int main() {
  double valor, valorAdicional;
  int op;
  cout<<"Digite o Valor do seu Ingresso: ";
  cin>>valor;
  std::cout << "Você é VIP?" << endl;
  cout << "1-NAO\n2-SIM"<< endl;
  Ingresso Ingresso1 = Ingresso(valor);
  cout << "Digite a Opção: ";
  cin>>op;
  if(op==1){
    Ingresso1.toString();
  }
  else if(op==2){
      cout << "Digite o Valor adicional do seu ingresso: ";
      cin>> valorAdicional;
      IngressoVIP IngressoVIP1 = IngressoVIP(valorAdicional, valor);
      IngressoVIP1.toString();
  }
  else{
    cout << "Opção Inválida";
  }
}