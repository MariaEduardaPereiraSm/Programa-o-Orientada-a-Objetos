#include "IngressoVIP.h"
#include <iostream>
#include <string>

using namespace std;

IngressoVIP::IngressoVIP(double novovalorAdicional, double valor):
  Ingresso(valor){
    this -> valorAdicional = novovalorAdicional;
}

void IngressoVIP::setVALORADICIONAL(double novovalorAdicional){
  this-> valorAdicional = novovalorAdicional;
}

double IngressoVIP::getVALORADICIONAL(){
  return this -> valorAdicional;
}

void IngressoVIP::toString(){
  cout<<"\n----Informações sobre o seu ingresso VIP----"<< endl;
  cout << "Valor normal do ingresso: " << getVALOR() << endl;
  cout << "Valor do VIP: " << getVALORADICIONAL()<<endl;
  cout << "Valor Total do Ingresso: " << getVALOR() + getVALORADICIONAL() << endl;
}