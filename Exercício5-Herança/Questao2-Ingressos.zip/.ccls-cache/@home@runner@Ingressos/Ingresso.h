#ifndef Ingresso_H
#define Ingresso_H

class Ingresso{
  public:
    double valor;

  Ingresso(double novovalor){
    this -> valor = novovalor;
  }

  void setVALOR(double novovalor);
  double getVALOR();
  void toString();
};

#endif